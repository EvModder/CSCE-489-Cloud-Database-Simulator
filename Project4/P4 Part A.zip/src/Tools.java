public class Tools{
	public static String[] splitUnlessEscaped(String str, String del){
		return null;//TODO: this
	}
}