
public class Image{
	String name, path;
	
	Image(String name, String path){
		this.name = name;
		this.path = path;
	}
}
