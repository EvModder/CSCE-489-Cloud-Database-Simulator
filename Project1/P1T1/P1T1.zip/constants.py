host = "34.233.78.56"
db = "fitness_424003778"
collection = "fitness_424003778"
